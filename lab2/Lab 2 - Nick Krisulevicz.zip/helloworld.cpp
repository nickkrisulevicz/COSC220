//Nick Krisulevicz
//Lab 2, part 1: helloworld.cpp
//09/14/2021

#include <iostream>
using namespace std;

int main()
{
    cout << "Hello world from Nick Krisulevicz!" << endl;
    return 0;
}